import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton
from datetime import datetime, timedelta
import config
from database import database

bot = telebot.TeleBot(config.BOT_TOKEN)

# Temporary memory dictionaries
user_reports = {}        # For Lost Items (Part 5)
user_found_reports = {}  # For Found Items (Part 6)
user_search_state = {}   # For Searching (Part 7)

# --- HELPER MENUS & CANCEL ---
def show_main_menu(message):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(KeyboardButton("🔴 I Lost Something"), KeyboardButton("🟢 I Found Something"))
    markup.row(KeyboardButton("🔍 Search"), KeyboardButton("📋 My Reports"))
    markup.row(KeyboardButton("🔔 Notifications"), KeyboardButton("❓ Help"))
    bot.send_message(message.chat.id, "Here is the main menu. What would you like to do?", reply_markup=markup)

def check_cancel(message):
    """Helper: Let users cancel by typing /start or Cancel anywhere. Clears ALL temporary dicts."""
    if message.content_type == 'text' and message.text in ['/start', '❌ Cancel', '🏠 Main Menu', '🔄 New Search']:
        if message.chat.id in user_reports:
            del user_reports[message.chat.id]
        if message.chat.id in user_found_reports:
            del user_found_reports[message.chat.id]
        if message.chat.id in user_search_state:
            del user_search_state[message.chat.id]
            
        if message.text == '/start':
            send_welcome(message)
        elif message.text == '🔄 New Search':
            start_search(message)
        else:
            bot.send_message(message.chat.id, "Action cancelled.")
            show_main_menu(message)
        return True
    return False

# --- REGISTRATION (PART 4) ---
@bot.message_handler(commands=['start'])
def send_welcome(message):
    telegram_id = message.from_user.id
    if database.get_user_by_telegram_id(telegram_id):
        bot.reply_to(message, "👋 Welcome back to KKWIEER Lost & Found!")
        show_main_menu(message)
    else:
        msg = bot.reply_to(message, "👋 Welcome to KKWIEER Lost & Found!\nLet's create your profile first.\n\nPlease enter your name:", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, process_name_step)

def process_name_step(message):
    name = message.text
    if not name or not name.strip():
        msg = bot.reply_to(message, "Please enter a valid name (cannot be empty). Try again:")
        bot.register_next_step_handler(msg, process_name_step)
        return
    database.create_user(message.from_user.id, message.from_user.username, name.strip())
    bot.send_message(message.chat.id, f"Profile created successfully, {name.strip()}!")
    show_main_menu(message)


# ==========================================
# --- PART 7: SEARCH WORKFLOW ---
# ==========================================

@bot.message_handler(func=lambda m: m.text == "🔍 Search")
def start_search(message):
    chat_id = message.chat.id
    if not database.get_user_by_telegram_id(message.from_user.id):
        bot.send_message(chat_id, "Please type /start to register first.")
        return
    
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("🔴 Lost Items", "🟢 Found Items", "🔎 Both")
    markup.add("🏠 Main Menu")
    
    msg = bot.send_message(chat_id, "🔍 *Search Lost & Found*\n\nChoose what you want to search:", parse_mode='Markdown', reply_markup=markup)
    bot.register_next_step_handler(msg, process_search_type)

def process_search_type(message):
    if check_cancel(message): return
    chat_id = message.chat.id
    text = message.text
    
    search_type = 'both'
    if text == "🔴 Lost Items": search_type = 'lost'
    elif text == "🟢 Found Items": search_type = 'found'
    elif text != "🔎 Both":
        msg = bot.send_message(chat_id, "Please select an option from the keyboard.")
        bot.register_next_step_handler(msg, process_search_type)
        return
        
    user_search_state[chat_id] = {'type': search_type, 'keyword': None, 'category': None, 'location': None, 'page': 0}
    show_search_filters(message)

def show_search_filters(message):
    chat_id = message.chat.id
    state = user_search_state.get(chat_id)
    if not state: return
    
    status_text = "🔍 *Search Filters*\n\nCurrent Filters:\n"
    status_text += f"• **Keyword:** {state['keyword'] if state['keyword'] else 'None'}\n"
    status_text += f"• **Category:** {state['category'] if state['category'] else 'None'}\n"
    status_text += f"• **Location:** {state['location'] if state['location'] else 'None'}\n\n"
    status_text += "What would you like to search by or add?"
    
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("🔎 Keyword", "📂 Category", "📍 Location")
    markup.add("✅ Search Now", "📋 Show All")
    markup.add("🔄 New Search", "🏠 Main Menu")
    
    msg = bot.send_message(chat_id, status_text, parse_mode='Markdown', reply_markup=markup)
    bot.register_next_step_handler(msg, process_search_filter_selection)

def process_search_filter_selection(message):
    if check_cancel(message): return
    chat_id = message.chat.id
    text = message.text
    
    if text == "🔎 Keyword":
        msg = bot.send_message(chat_id, "Enter a keyword to search (e.g. phone, black, keys):", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, process_search_keyword)
    elif text == "📂 Category":
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("📱 Electronics", "🎒 Bags", "👛 Wallet/Purse", "🪪 ID/Card")
        markup.add("🔑 Keys", "📚 Books/Notes", "👕 Clothing", "💍 Accessories")
        markup.add("💧 Bottle", "📝 Other", "❌ Cancel")
        msg = bot.send_message(chat_id, "Select a category to filter by:", reply_markup=markup)
        bot.register_next_step_handler(msg, process_search_category)
    elif text == "📍 Location":
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("📚 Library", "🍔 Canteen", "🏫 Classroom")
        markup.add("🏢 Department", "🏃 Ground", "🅿️ Parking")
        markup.add("🚌 Bus Area", "🏢 Administrative Building", "📍 Other")
        markup.add("❌ Cancel")
        msg = bot.send_message(chat_id, "Select a location to filter by:", reply_markup=markup)
        bot.register_next_step_handler(msg, process_search_location)
    elif text == "📋 Show All":
        # Clear all filters and execute
        user_search_state[chat_id]['keyword'] = None
        user_search_state[chat_id]['category'] = None
        user_search_state[chat_id]['location'] = None
        execute_search(chat_id)
    elif text == "✅ Search Now":
        execute_search(chat_id)
    else:
        show_search_filters(message)

def process_search_keyword(message):
    if check_cancel(message): return
    if message.text.strip():
        user_search_state[message.chat.id]['keyword'] = message.text.strip()
    show_search_filters(message)

def process_search_category(message):
    if check_cancel(message): return
    if message.text == "📝 Other":
        msg = bot.send_message(message.chat.id, "Please type the custom category to search:", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, process_search_keyword_category)
    else:
        user_search_state[message.chat.id]['category'] = message.text.strip()
        show_search_filters(message)

def process_search_keyword_category(message):
    if check_cancel(message): return
    user_search_state[message.chat.id]['category'] = message.text.strip()
    show_search_filters(message)

def process_search_location(message):
    if check_cancel(message): return
    if message.text == "📍 Other":
        msg = bot.send_message(message.chat.id, "Please type the exact location to search:", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, process_search_keyword_location)
    else:
        user_search_state[message.chat.id]['location'] = message.text.strip()
        show_search_filters(message)

def process_search_keyword_location(message):
    if check_cancel(message): return
    user_search_state[message.chat.id]['location'] = message.text.strip()
    show_search_filters(message)

def execute_search(chat_id):
    """Runs the database query based on current filters and shows paginated results."""
    state = user_search_state.get(chat_id)
    if not state: return
    
    limit = 10
    offset = state['page'] * limit
    
    results, total_results = database.search_items(
        state['type'], state['keyword'], state['category'], state['location'], offset, limit
    )
    
    if total_results == 0:
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("🔄 New Search", "🏠 Main Menu")
        bot.send_message(chat_id, "🔍 No matching reports found.\nTry changing your keyword, category, or location.", reply_markup=markup)
        return

    # Format Results
    reply_text = f"🔍 *Search Results* (Page {state['page'] + 1})\n\n"
    
    # Setup Inline Keyboard for selecting an item
    inline_markup = InlineKeyboardMarkup()
    
    for row in results:
        is_lost = row['type'] == 'lost'
        icon = "🔴 Lost" if is_lost else "🟢 Found"
        id_prefix = "#L" if is_lost else "#F"
        report_id = f"{id_prefix}{row['id']}"
        
        reply_text += f"{icon} — {row['item_name']}\n📍 {row['location']} | 📅 {row['date']} | 🆔 {report_id}\n\n"
        
        # Add an inline button for this specific item (Callback format: view:lost:10)
        inline_markup.add(InlineKeyboardButton(text=f"View {report_id}", callback_data=f"view:{row['type']}:{row['id']}"))

    # Pagination buttons
    nav_buttons = []
    if state['page'] > 0:
        nav_buttons.append(InlineKeyboardButton("⬅️ Prev", callback_data="search:prev"))
    if offset + limit < total_results:
        nav_buttons.append(InlineKeyboardButton("Next ➡️", callback_data="search:next"))
    
    if nav_buttons:
        inline_markup.row(*nav_buttons)

    # We send this with a standard reply keyboard below it just in case they want to exit
    bottom_markup = ReplyKeyboardMarkup(resize_keyboard=True)
    bottom_markup.add("🔄 New Search", "🏠 Main Menu")
    
    bot.send_message(chat_id, "Select a report to view details:", reply_markup=bottom_markup)
    bot.send_message(chat_id, reply_text, parse_mode='Markdown', reply_markup=inline_markup)

# --- INLINE BUTTON HANDLERS (CALLBACKS) ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('search:'))
def handle_pagination(call):
    chat_id = call.message.chat.id
    if chat_id not in user_search_state:
        bot.answer_callback_query(call.id, "Search session expired. Start a new search.")
        return
        
    action = call.data.split(":")[1]
    if action == "next":
        user_search_state[chat_id]['page'] += 1
    elif action == "prev":
        user_search_state[chat_id]['page'] -= 1
        
    # Delete the old inline keyboard message to keep chat clean
    bot.delete_message(chat_id, call.message.message_id)
    execute_search(chat_id)

@bot.callback_query_handler(func=lambda call: call.data.startswith('view:'))
def handle_view_item(call):
    chat_id = call.message.chat.id
    _, item_type, item_id = call.data.split(':')
    
    # Fetch details safely
    item = database.get_item_details(item_type, int(item_id))
    
    # Delete the search list message so it doesn't clutter
    bot.delete_message(chat_id, call.message.message_id)
    
    if not item:
        bot.send_message(chat_id, "Sorry, this report is no longer available (it may have been deleted or recovered).")
        execute_search(chat_id) # Show results again
        return
        
    is_lost = item_type == 'lost'
    icon = "🔴 Lost Item" if is_lost else "🟢 Found Item"
    id_prefix = "#L" if is_lost else "#F"
    report_id = f"{id_prefix}{item['id']}"
    status_icon = "🔴 LOST" if is_lost else "🟢 FOUND"
    
    details = (
        f"{icon}\n"
        f"**Report ID:** {report_id}\n\n"
        f"**Category:** {item['category']}\n"
        f"**Item:** {item['item_name']}\n"
        f"**Description:**\n{item['description']}\n\n"
        f"**Location:** {item['location']}\n"
        f"**Date:** {item['found_date'] if not is_lost else item['lost_date']}\n"
        f"**Approximate Time:** {item['approximate_time'] if item['approximate_time'] else 'Not provided'}\n"
        f"**Photo:** {'✅ Attached' if item['photo_id'] else '❌ Not provided'}\n\n"
        f"**Status:** {status_icon}"
    )
    
    # Add a "Back to Results" inline button
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("⬅️ Back to Results", callback_data="search:back"))
    
    if item['photo_id']:
        bot.send_photo(chat_id, item['photo_id'], caption=details, parse_mode='Markdown', reply_markup=markup)
    else:
        bot.send_message(chat_id, details, parse_mode='Markdown', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == 'search:back')
def handle_back_to_results(call):
    # Just delete the item detail view and reload the search results
    bot.delete_message(call.message.chat.id, call.message.message_id)
    execute_search(call.message.chat.id)


# ==========================================
# --- PART 5 & 6 COMPATIBILITY SHIMS ---
# (Keeping the exact logic from Parts 5/6 here)
# ==========================================

def route_next_step(message, next_function, state_dict):
    chat_id = message.chat.id
    if state_dict[chat_id].get('is_editing'):
        state_dict[chat_id]['is_editing'] = False
        if state_dict == user_reports: show_review(message)
        else: show_found_review(message)
    else:
        next_function(message)

@bot.message_handler(func=lambda m: m.text == "🔴 I Lost Something")
def start_lost_report(message):
    chat_id = message.chat.id
    if not database.get_user_by_telegram_id(message.from_user.id):
        bot.send_message(chat_id, "Please type /start to register first.")
        return
    user_reports[chat_id] = {'is_editing': False}
    ask_category(message, user_reports, process_category)

@bot.message_handler(func=lambda m: m.text == "🟢 I Found Something")
def start_found_report(message):
    chat_id = message.chat.id
    if not database.get_user_by_telegram_id(message.from_user.id):
        bot.send_message(chat_id, "Please type /start to register first.")
        return
    user_found_reports[chat_id] = {'is_editing': False}
    ask_category(message, user_found_reports, process_found_category)

# Unified UI functions for Lost/Found so we don't repeat 500 lines of code
def ask_category(message, state_dict, next_func):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("📱 Electronics", "🎒 Bags", "👛 Wallet/Purse", "🪪 ID/Card")
    markup.add("🔑 Keys", "📚 Books/Notes", "👕 Clothing", "💍 Accessories")
    markup.add("💧 Bottle", "📝 Other", "❌ Cancel")
    msg = bot.send_message(message.chat.id, "What category is the item?", reply_markup=markup)
    bot.register_next_step_handler(msg, next_func)

def process_category(message):
    if check_cancel(message): return
    if message.text == "📝 Other":
        msg = bot.send_message(message.chat.id, "Please type the custom category:", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'category', ask_item_name, user_reports))
    else:
        user_reports[message.chat.id]['category'] = message.text.strip()
        route_next_step(message, ask_item_name, user_reports)

def process_found_category(message):
    if check_cancel(message): return
    if message.text == "📝 Other":
        msg = bot.send_message(message.chat.id, "Please type the custom category:", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'category', ask_found_item_name, user_found_reports))
    else:
        user_found_reports[message.chat.id]['category'] = message.text.strip()
        route_next_step(message, ask_found_item_name, user_found_reports)

def process_text_input(message, field, next_func, state_dict):
    if check_cancel(message): return
    if not message.text or not message.text.strip():
        msg = bot.send_message(message.chat.id, "Input cannot be empty. Type again:")
        bot.register_next_step_handler(msg, lambda m: process_text_input(m, field, next_func, state_dict))
        return
    state_dict[message.chat.id][field] = message.text.strip()
    route_next_step(message, next_func, state_dict)

def ask_item_name(message):
    msg = bot.send_message(message.chat.id, "What did you lose? (e.g. Black Samsung Galaxy Buds)", reply_markup=ReplyKeyboardRemove())
    bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'item_name', ask_description, user_reports))
def ask_found_item_name(message):
    msg = bot.send_message(message.chat.id, "What did you find? (e.g. Black Samsung Galaxy Buds)", reply_markup=ReplyKeyboardRemove())
    bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'item_name', ask_found_description, user_found_reports))

def ask_description(message):
    msg = bot.send_message(message.chat.id, "Describe the item and any identifying details:")
    bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'description', ask_location, user_reports))
def ask_found_description(message):
    msg = bot.send_message(message.chat.id, "Describe the item and any identifying details:")
    bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'description', ask_found_location, user_found_reports))

def ask_location_shared(message, next_func):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("📚 Library", "🍔 Canteen", "🏫 Classroom")
    markup.add("🏢 Department", "🏃 Ground", "🅿️ Parking")
    markup.add("🚌 Bus Area", "🏢 Administrative Building", "📍 Other")
    msg = bot.send_message(message.chat.id, "Where did you lose/find it?", reply_markup=markup)
    bot.register_next_step_handler(msg, next_func)

def ask_location(message): ask_location_shared(message, process_location)
def ask_found_location(message): ask_location_shared(message, process_found_location)

def process_location(message):
    if check_cancel(message): return
    if message.text == "📍 Other":
        msg = bot.send_message(message.chat.id, "Please type the exact location:", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'location', ask_date, user_reports))
    else:
        user_reports[message.chat.id]['location'] = message.text.strip()
        route_next_step(message, ask_date, user_reports)

def process_found_location(message):
    if check_cancel(message): return
    if message.text == "📍 Other":
        msg = bot.send_message(message.chat.id, "Please type the exact location:", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, lambda m: process_text_input(m, 'location', ask_found_date, user_found_reports))
    else:
        user_found_reports[message.chat.id]['location'] = message.text.strip()
        route_next_step(message, ask_found_date, user_found_reports)

def ask_date_shared(message, next_func):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("📅 Today", "📅 Yesterday", "📅 Enter Date")
    msg = bot.send_message(message.chat.id, "When did this happen?", reply_markup=markup)
    bot.register_next_step_handler(msg, next_func)

def ask_date(message): ask_date_shared(message, lambda m: process_date(m, user_reports, ask_time))
def ask_found_date(message): ask_date_shared(message, lambda m: process_date(m, user_found_reports, ask_found_time))

def process_date(message, state_dict, next_func):
    if check_cancel(message): return
    text = message.text.strip()
    today = datetime.today().date()
    
    if text == "📅 Today":
        state_dict[message.chat.id]['date'] = today.strftime("%Y-%m-%d")
        route_next_step(message, next_func, state_dict)
    elif text == "📅 Yesterday":
        yesterday = today - timedelta(days=1)
        state_dict[message.chat.id]['date'] = yesterday.strftime("%Y-%m-%d")
        route_next_step(message, next_func, state_dict)
    elif text == "📅 Enter Date":
        msg = bot.send_message(message.chat.id, "Enter date in DD-MM-YYYY format (e.g. 10-09-2026):", reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(msg, lambda m: process_custom_date(m, state_dict, next_func))
    else:
        msg = bot.send_message(message.chat.id, "Please select from the keyboard.")
        bot.register_next_step_handler(msg, lambda m: process_date(m, state_dict, next_func))

def process_custom_date(message, state_dict, next_func):
    if check_cancel(message): return
    try:
        parsed = datetime.strptime(message.text.strip(), "%d-%m-%Y").date()
        if parsed > datetime.today().date():
            msg = bot.send_message(message.chat.id, "Date cannot be in the future! Try again:")
            bot.register_next_step_handler(msg, lambda m: process_custom_date(m, state_dict, next_func))
            return
        state_dict[message.chat.id]['date'] = parsed.strftime("%Y-%m-%d")
        route_next_step(message, next_func, state_dict)
    except ValueError:
        msg = bot.send_message(message.chat.id, "Invalid format. Use DD-MM-YYYY:")
        bot.register_next_step_handler(msg, lambda m: process_custom_date(m, state_dict, next_func))

def ask_time_shared(message, next_func):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("⏭️ Skip")
    msg = bot.send_message(message.chat.id, "Approximately what time?", reply_markup=markup)
    bot.register_next_step_handler(msg, next_func)

def ask_time(message): ask_time_shared(message, lambda m: process_time(m, user_reports, ask_photo))
def ask_found_time(message): ask_time_shared(message, lambda m: process_time(m, user_found_reports, ask_found_photo))

def process_time(message, state_dict, next_func):
    if check_cancel(message): return
    state_dict[message.chat.id]['time'] = None if message.text == "⏭️ Skip" else message.text.strip()
    route_next_step(message, next_func, state_dict)

def ask_photo_shared(message, next_func):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("⏭️ Skip Photo")
    msg = bot.send_message(message.chat.id, "Upload a photo if you have one.", reply_markup=markup)
    bot.register_next_step_handler(msg, next_func)

def ask_photo(message): ask_photo_shared(message, lambda m: process_photo(m, user_reports, show_review))
def ask_found_photo(message): ask_photo_shared(message, lambda m: process_photo(m, user_found_reports, show_found_review))

def process_photo(message, state_dict, next_func):
    if check_cancel(message): return
    if message.content_type == 'photo':
        state_dict[message.chat.id]['photo_id'] = message.photo[-1].file_id
        route_next_step(message, next_func, state_dict)
    elif message.content_type == 'text' and message.text == "⏭️ Skip Photo":
        state_dict[message.chat.id]['photo_id'] = None
        route_next_step(message, next_func, state_dict)
    else:
        msg = bot.send_message(message.chat.id, "Please upload a photo or press Skip Photo.")
        bot.register_next_step_handler(msg, lambda m: process_photo(m, state_dict, next_func))

def show_review(message):
    report = user_reports.get(message.chat.id)
    if not report: return
    summary = f"🔴 *Review Lost Item*\n\n**Category:** {report['category']}\n**Item:** {report['item_name']}\n**Description:**\n{report['description']}\n\n**Location:** {report['location']}\n**Date:** {report['date']}\n**Photo:** {'✅' if report.get('photo_id') else '❌'}"
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("✅ Submit", "✏️ Edit", "❌ Cancel")
    if report.get('photo_id'): bot.send_photo(message.chat.id, report['photo_id'], caption=summary, parse_mode='Markdown', reply_markup=markup)
    else: bot.send_message(message.chat.id, summary, parse_mode='Markdown', reply_markup=markup)

def show_found_review(message):
    report = user_found_reports.get(message.chat.id)
    if not report: return
    summary = f"🟢 *Review Found Item*\n\n**Category:** {report['category']}\n**Item:** {report['item_name']}\n**Description:**\n{report['description']}\n\n**Location:** {report['location']}\n**Date:** {report['date']}\n**Photo:** {'✅' if report.get('photo_id') else '❌'}"
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("✅ Submit Found", "✏️ Edit Found", "❌ Cancel")
    if report.get('photo_id'): bot.send_photo(message.chat.id, report['photo_id'], caption=summary, parse_mode='Markdown', reply_markup=markup)
    else: bot.send_message(message.chat.id, summary, parse_mode='Markdown', reply_markup=markup)

@bot.message_handler(func=lambda m: m.text in ["✅ Submit", "✏️ Edit", "❌ Cancel"] and m.chat.id in user_reports)
def handle_lost_submit(message):
    chat_id = message.chat.id
    if message.text == "✅ Submit":
        r = user_reports[chat_id]
        report_id = database.save_lost_item(message.from_user.id, r['category'], r['item_name'], r['description'], r['location'], r['date'], r['time'], r['photo_id'])
        del user_reports[chat_id]
        bot.send_message(chat_id, f"✅ Lost item reported successfully!\nReport ID: 🔴 **#L{report_id}**", parse_mode='Markdown')
        show_main_menu(message)
    elif message.text == "✏️ Edit":
        user_reports[chat_id]['is_editing'] = True
        ask_category(message, user_reports, process_category) # Simplified editing for code length
    elif message.text == "❌ Cancel":
        del user_reports[chat_id]
        bot.send_message(chat_id, "Cancelled.")
        show_main_menu(message)

@bot.message_handler(func=lambda m: m.text in ["✅ Submit Found", "✏️ Edit Found", "❌ Cancel"] and m.chat.id in user_found_reports)
def handle_found_submit(message):
    chat_id = message.chat.id
    if message.text == "✅ Submit Found":
        r = user_found_reports[chat_id]
        report_id = database.save_found_item(message.from_user.id, r['category'], r['item_name'], r['description'], r['location'], r['date'], r['time'], r['photo_id'])
        del user_found_reports[chat_id]
        bot.send_message(chat_id, f"✅ Found item reported successfully!\nReport ID: 🟢 **#F{report_id}**", parse_mode='Markdown')
        show_main_menu(message)
    elif message.text == "✏️ Edit Found":
        user_found_reports[chat_id]['is_editing'] = True
        ask_category(message, user_found_reports, process_found_category)
    elif message.text == "❌ Cancel":
        del user_found_reports[chat_id]
        bot.send_message(chat_id, "Cancelled.")
        show_main_menu(message)

# ==========================================
# --- FALLBACKS ---
# ==========================================

@bot.message_handler(func=lambda message: message.text in ["📋 My Reports", "🔔 Notifications"])
def handle_coming_soon(message):
    bot.reply_to(message, "This feature will be available soon.")

@bot.message_handler(func=lambda message: message.text == "❓ Help")
def handle_help(message):
    bot.reply_to(message, "Use 'I Lost Something' or 'I Found Something' to report, or 'Search' to browse active reports!")

@bot.message_handler(func=lambda message: message.text in ["🏠 Main Menu", "⬅️ Back"])
def handle_global_main_menu(message):
    # Clear any leftover search data
    if message.chat.id in user_search_state:
        del user_search_state[message.chat.id]
    show_main_menu(message)

@bot.message_handler(func=lambda message: message.text == "🔄 New Search")
def handle_global_new_search(message):
    # Clear leftover search data and restart search
    if message.chat.id in user_search_state:
        del user_search_state[message.chat.id]
    start_search(message)

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, "I didn't understand that. Please use the menu buttons.")

if __name__ == "__main__":
    database.init_db()
    print("Bot is successfully running... Press Ctrl+C in terminal to stop.")
    bot.infinity_polling()