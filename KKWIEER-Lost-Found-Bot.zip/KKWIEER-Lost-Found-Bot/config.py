import os
from dotenv import load_dotenv

# Load variables from the .env file
load_dotenv()

# Get the token safely
BOT_TOKEN = os.getenv("BOT_TOKEN")

if not BOT_TOKEN:
    raise ValueError("No BOT_TOKEN found. Check your .env file.")