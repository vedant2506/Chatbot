import sqlite3
import os

# Define the path where the database file will be saved
DB_PATH = os.path.join(os.path.dirname(__file__), "lost_found.db")

def get_connection():
    """Helper function to get a database connection with Foreign Keys enabled."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    # This allows us to access columns by name (e.g., row['item_name'])
    conn.row_factory = sqlite3.Row 
    return conn

def init_db():
    """Creates the database and all required tables if they don't exist."""
    with get_connection() as conn:
        cursor = conn.cursor()
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER UNIQUE NOT NULL,
            username TEXT,
            full_name TEXT,
            registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active INTEGER DEFAULT 1
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS lost_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            item_name TEXT NOT NULL,
            description TEXT,
            location TEXT,
            lost_date DATE,
            approximate_time TEXT,
            photo_id TEXT,
            status TEXT DEFAULT 'LOST', 
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS found_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            item_name TEXT NOT NULL,
            description TEXT,
            location TEXT,
            found_date DATE,
            approximate_time TEXT,
            photo_id TEXT,
            status TEXT DEFAULT 'FOUND',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS matches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lost_item_id INTEGER NOT NULL,
            found_item_id INTEGER NOT NULL,
            score REAL,
            status TEXT DEFAULT 'PENDING',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (lost_item_id) REFERENCES lost_items(id) ON DELETE CASCADE,
            FOREIGN KEY (found_item_id) REFERENCES found_items(id) ON DELETE CASCADE,
            UNIQUE(lost_item_id, found_item_id)
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            notification_type TEXT,
            lost_item_id INTEGER,
            found_item_id INTEGER,
            message TEXT NOT NULL,
            is_read INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (lost_item_id) REFERENCES lost_items(id) ON DELETE SET NULL,
            FOREIGN KEY (found_item_id) REFERENCES found_items(id) ON DELETE SET NULL
        )''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reporter_id INTEGER NOT NULL,
            lost_item_id INTEGER,
            found_item_id INTEGER,
            reason TEXT NOT NULL,
            details TEXT,
            status TEXT DEFAULT 'PENDING',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (lost_item_id) REFERENCES lost_items(id) ON DELETE CASCADE,
            FOREIGN KEY (found_item_id) REFERENCES found_items(id) ON DELETE CASCADE
        )''')
        
        conn.commit()
        print("Database initialized successfully.")

# --- PART 4 FUNCTIONS ---
def get_user_by_telegram_id(telegram_id):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
        return cursor.fetchone()

def create_user(telegram_id, username, full_name):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (telegram_id, username, full_name) VALUES (?, ?, ?)",
            (telegram_id, username, full_name)
        )
        conn.commit()

# --- PART 5 & 6 FUNCTIONS ---
def save_lost_item(telegram_id, category, item_name, description, location, lost_date, approximate_time, photo_id):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (telegram_id,))
        user_row = cursor.fetchone()
        if not user_row: return None
        
        cursor.execute('''
            INSERT INTO lost_items (user_id, category, item_name, description, location, lost_date, approximate_time, photo_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (user_row['id'], category, item_name, description, location, lost_date, approximate_time, photo_id))
        conn.commit()
        return cursor.lastrowid

def save_found_item(telegram_id, category, item_name, description, location, found_date, approximate_time, photo_id):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (telegram_id,))
        user_row = cursor.fetchone()
        if not user_row: return None
        
        cursor.execute('''
            INSERT INTO found_items (user_id, category, item_name, description, location, found_date, approximate_time, photo_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (user_row['id'], category, item_name, description, location, found_date, approximate_time, photo_id))
        conn.commit()
        return cursor.lastrowid

# ==========================================
# --- PART 7: SEARCH FUNCTIONS ---
# ==========================================

def search_items(search_type, keyword=None, category=None, location=None, offset=0, limit=10):
    """Searches across Lost, Found, or both using provided filters safely."""
    with get_connection() as conn:
        cursor = conn.cursor()
        queries = []
        
        # 1. Build the base virtual table (Combining lost and found safely)
        if search_type in ['lost', 'both']:
            queries.append("SELECT 'lost' as type, id, category, item_name, description, location, lost_date as date, approximate_time as time, photo_id, status FROM lost_items WHERE status = 'LOST'")
        if search_type in ['found', 'both']:
            queries.append("SELECT 'found' as type, id, category, item_name, description, location, found_date as date, approximate_time as time, photo_id, status FROM found_items WHERE status = 'FOUND'")
            
        base_query = " UNION ALL ".join(queries)
        
        # 2. Wrap it so we can apply filters to the combined data
        final_query = f"SELECT * FROM ({base_query}) WHERE 1=1"
        params = []
        
        # 3. Add filters safely using parameterized '?'
        if category:
            final_query += " AND category = ?"
            params.append(category)
        if location:
            final_query += " AND location = ?"
            params.append(location)
        if keyword:
            final_query += " AND (item_name LIKE ? OR description LIKE ? OR category LIKE ? OR location LIKE ?)"
            kw = f"%{keyword}%"
            params.extend([kw, kw, kw, kw])
            
        # 4. Count total results (for pagination)
        count_query = f"SELECT COUNT(*) FROM ({final_query})"
        cursor.execute(count_query, params)
        total_results = cursor.fetchone()[0]
        
        # 5. Get the actual paginated data
        final_query += " ORDER BY date DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        cursor.execute(final_query, params)
        results = cursor.fetchall()
        
        return results, total_results

def get_item_details(item_type, item_id):
    """Fetches a specific item's details. (Does NOT return personal user data)."""
    with get_connection() as conn:
        cursor = conn.cursor()
        if item_type == 'lost':
            cursor.execute("SELECT * FROM lost_items WHERE id = ? AND status = 'LOST'", (item_id,))
        elif item_type == 'found':
            cursor.execute("SELECT * FROM found_items WHERE id = ? AND status = 'FOUND'", (item_id,))
        else:
            return None
        return cursor.fetchone()